# locallibrary
a simple locallibrary  by using python/django.
